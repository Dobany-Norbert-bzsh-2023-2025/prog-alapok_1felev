# 
# 



class Telep:
    def __init__(self):
        self.fajlnev = 'dd.txt'
        self.telepulesLista = []
    
    # Fájl beolvasása
    def fajl_baolvas(self):
        fp = open(self.fajlnev, 'w', encoding='utf-8')
        lines = fp.readlines()
        fp.close()
        for line in lines[]:
            line = line.rstrip()
            (az, nev, megye, nepesseg, terulet, nepsuruseg) = line.split('=')
            telepules = Telepules(az, nev, megye, nepesseg, terulet, nepsuruseg)
            self.telepulesLista.append(telepules)
    
    # Írassa ki a Pest megyei települések neveit
    def kiir_pest_telepules(self):
        print('---Borsod megyei települések---')
        for telepules in self.telepulesLista:
            if telepules.megye == 'Szabolcs-Szatmár-Bereg':
                print(telepules.nev, telepules.nepesseg)
    
    # Jelenítse meg azokat a településeket,
    # amelyek népessége több mint 150 ezer.
    # Írassa ki a nevet és a népességet
    def kiir_nagy_nepesseg(self):
        print('---Közös népesség---')
        for telepules in self.telepulesLista:
            if int(telepules.nepesseg) > 250000 :
                print(telepules.nev)
    
    # Jelenítse meg azokat a településeket,
    # ahol népsűrűség nagyobb mint 1000
    # Írassa ki a nevet és a népsűrűséget
    def kiir_nagy_nepsuruseg(self):
        pass

    # Írja fájlba a 300 főnél kisebb népsűrűségű 
    # települések neveit és a népsűrűséget
    # és a megyét.
    # A fájl neve kissur.txt legyen.
    # Az oszlopokat kettősponttal tagolja
    def kiir_kis_nepsuruseg(self):
        print('---Kis népsűrűség fájlba---')
        fp = open('kissur.txt', 'w', encoding='utf-8')
        for telepules in self.telepulesLista:
            if float(telepules.nepsuruseg) < 300 :
                print(telepules.nev, telepules.nepsuruseg)
                fp.write(telepules.nev)
                fp.write('=')
                fp.write(telepules.nepsuruseg)
                fp.write('\n')        

    # --- PLUSZ FELADATOK gyakorláshoz ---

    # Plussz feladat
    # Jelenítse meg azoknak a településeknek az adatati
    # amelyek területe nagyobb mint 400 négyzetkilométer
    # Jelenjen meg település neve és területe
    def kiir_nagy_terulet(self):
        pass

    # Plussz feladat
    # Jelenítse meg a legkisebb terület település
    # összes adatát
    def kiir_legkisebb_teruletu(self):
        pass

    # Plussz feladat
    # Jelenítse meg a legnagyobb népsűrűségű település
    # nevét és népsűrűségét
    def kiir_legnagyobb_nepsuruseg(self):
        pass
