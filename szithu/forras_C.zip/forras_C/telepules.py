class Telepules:
    def __init__(self, az, nev, megye, nepesseg, terulet):
        self.az = az
        self.nev = nev
        self.megye = megye
        self.nepesseg = nepesseg
        self.terulet = terulet
        