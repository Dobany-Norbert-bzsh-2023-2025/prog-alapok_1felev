t1=
"""
if t1<0:
    print("negativ")
elif t1==0:
    print("nula")
else:
    print("pozitiv")
"""
    
if t1<0:
    print("negativ")
elif t1==0:
    print("nula")
elif t1>0 and t1<=10:
    print("0 es 10 kozotti szam")
else:
    print("10-nel nagyobb")